% Test script for Numerical Methods OOP implementation

% Differential equation example: dy/dx = x + y, y(0) = 1
diffSolver = DifferentialSolver( ...
    'Solve dy/dx = x + y using Euler''s method', ...
    @(x, y) x + y, 0, 1, 0.1, 10);

% Integral example: ∫_0^1 e^x dx
intSolver = IntegralSolver( ...
    'Integrate e^x from 0 to 1 using trapezoidal rule', ...
    @(x) exp(x), 0, 1, 100);

% Display and solve differential problem
diffSolver.displayDescription();
diffResult = diffSolver.solve();
fprintf('Differential equation result: %.6f\n', diffResult);

% Display and solve integral problem
intSolver.displayDescription();
intResult = intSolver.solve();
fprintf('Integral result: %.6f\n', intResult);

