classdef (Abstract) NumericalMethod
    % NumericalMethod - Abstract base class for numerical methods
    % Demonstrates abstraction, encapsulation, and polymorphism
    
    properties (Access = protected)
        % Protected property: accessible only within this class and subclasses
        problemDescription
    end
    
    methods
        function obj = NumericalMethod(description)
            % Constructor: sets the problem description
            obj.problemDescription = description;
        end
        
        function displayDescription(obj)
            % Public method to display the problem description
            fprintf('Problem: %s\n', obj.problemDescription);
        end
    end
    
    methods (Abstract)
        % Abstract method: must be implemented by subclasses
        result = solve(obj)
    end
end

