classdef DifferentialSolver < NumericalMethod
    % DifferentialSolver - Solves ODEs using Euler's method
    
    properties (Access = private)
        f       % Function handle for dy/dx
        x0      % Initial x value
        y0      % Initial y value
        h       % Step size
        n       % Number of steps
    end
    
    methods
        function obj = DifferentialSolver(description, f, x0, y0, h, n)
            % Call parent constructor
            obj@NumericalMethod(description);
            % Store parameters privately
            obj.f = f;
            obj.x0 = x0;
            obj.y0 = y0;
            obj.h = h;
            obj.n = n;
        end
        
        function result = solve(obj)
            % Implements Euler's method for ODEs
            x = obj.x0;
            y = obj.y0;
            for i = 1:obj.n
                y = y + obj.h * obj.f(x, y);
                x = x + obj.h;
            end
            result = y;
        end
    end
end

