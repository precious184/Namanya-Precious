classdef IntegralSolver < NumericalMethod
    % IntegralSolver - Solves definite integrals using the trapezoidal rule
    
    properties (Access = private)
        f   % Function handle for f(x)
        a   % Lower limit
        b   % Upper limit
        n   % Number of subintervals
    end
    
    methods
        function obj = IntegralSolver(description, f, a, b, n)
            % Call parent constructor
            obj@NumericalMethod(description);
            % Store parameters privately
            obj.f = f;
            obj.a = a;
            obj.b = b;
            obj.n = n;
        end
        
        function result = solve(obj)
            % Implements trapezoidal rule
            h = (obj.b - obj.a) / obj.n;
            sumVal = obj.f(obj.a) + obj.f(obj.b);
            for i = 1:obj.n-1
                sumVal = sumVal + 2 * obj.f(obj.a + i*h);
            end
            result = (h / 2) * sumVal;
        end
    end
end

